﻿
    public interface IDetainable
    {
        string Id { get; }

        bool IsDetained(string id);
    }
