﻿
    public interface IDetainable
    {
        string Id { get; }
    }
