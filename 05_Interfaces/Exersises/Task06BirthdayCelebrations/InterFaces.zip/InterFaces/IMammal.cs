﻿
    public interface IMammal:INameable
    {
        string Birthay { get; }
        bool HaveBirthay(string birthay);
    }
