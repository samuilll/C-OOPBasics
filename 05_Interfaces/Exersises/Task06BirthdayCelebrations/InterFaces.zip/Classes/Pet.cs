﻿
    public class Pet:Mammal
    {
        public Pet(string name,string birthday):base(name,birthday)
        {
        }
    }
