﻿
    public interface ISpecializedSoldier:IPrivate
    {
        string Corps { get; }
    }
