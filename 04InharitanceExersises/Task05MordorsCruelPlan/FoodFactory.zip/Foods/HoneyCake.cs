﻿using System;
using System.Collections.Generic;
using System.Text;


  public  class HoneyCake:Food
    {
    public HoneyCake() : base(5)
    {

    }
}

