﻿using System;
using System.Collections.Generic;
using System.Text;


  public  class Food
    {
    private int pointsOfHappines;

    public Food(int points)
    {
        this.PointsOfHappines = points;
    }

    public int PointsOfHappines { get; private set; }
    }

