﻿using System;
using System.Collections.Generic;
using System.Text;


  public  class JavaScript:Mood
    {
    private int happinesPoints;

    public JavaScript(int happinessPoints):base(happinessPoints)
    {
    }
}

