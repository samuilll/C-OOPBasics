﻿using System;
using System.Collections.Generic;
using System.Text;


  public  class Mood
    {

    private int happinesPoints;

    public Mood(int happinessPoints)
    {
         this.happinesPoints=happinessPoints;
    }
    }

