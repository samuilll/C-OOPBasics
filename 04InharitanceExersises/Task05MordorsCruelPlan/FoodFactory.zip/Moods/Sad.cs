﻿using System;
using System.Collections.Generic;
using System.Text;


  public  class Sad:Mood
    {
    private int happinesPoints;

    public Sad(int happinessPoints):base(happinessPoints)
    {
    }
}

