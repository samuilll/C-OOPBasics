﻿using System;
using System.Collections.Generic;
using System.Text;


  public  class Angry:Mood
    {
    private int happinesPoints;

    public Angry(int happinessPoints):base(happinessPoints)
    {
    }
}

