﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


    class ExceptionMessages
    {
    public const string AuthorException = "Author not valid!";
    public const string TitleException = "Title not valid!";
    public const string PriceException = "Price not valid!";

}

