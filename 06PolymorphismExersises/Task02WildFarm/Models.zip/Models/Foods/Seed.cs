﻿
    public class Seed:Food
    {
        public Seed(int quantity) : base(quantity)
        {
        }
    }
