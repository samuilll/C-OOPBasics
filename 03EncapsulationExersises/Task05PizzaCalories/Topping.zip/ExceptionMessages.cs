﻿using System;
using System.Collections.Generic;
using System.Text;


 public   class ExceptionMessages
    {

   public const string InvalidDoughType = "Invalid type of dough.";
    public const string InvalidDoughWeight = "Dough weight should be in the range [1..200].";
    public const string TooMuchToppings = "Number of toppings should be in range [0..10].";
    public const string PizzaNameException = "Pizza name should be between 1 and 15 symbols.";


}

