﻿
    public interface IBayer
    {
        int Food { get; }

        void BuyFood();
    }
