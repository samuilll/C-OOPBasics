﻿
    public interface IGroupable
    {
        string Group { get; }
    }
