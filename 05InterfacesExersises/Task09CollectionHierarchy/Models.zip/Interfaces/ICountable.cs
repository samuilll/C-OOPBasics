﻿
    public interface IMyList:IAddable,IRemovable
    {
        int Used { get; }
    }
