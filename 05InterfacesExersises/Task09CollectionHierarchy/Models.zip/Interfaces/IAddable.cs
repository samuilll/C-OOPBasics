﻿
    public interface IAddable
    {
        int Add(string element);
    }
