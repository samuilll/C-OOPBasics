﻿
    public interface IRemovable
    {
        string Remove();
    }
