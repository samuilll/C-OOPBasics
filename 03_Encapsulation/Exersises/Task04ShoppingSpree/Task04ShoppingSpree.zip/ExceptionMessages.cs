﻿using System;
using System.Collections.Generic;
using System.Text;


 public   class ExceptionMessages
    {

    public const string MoneyException = "Money cannot be negative";

    public const string NameExeption = "Name cannot be empty";
    }

