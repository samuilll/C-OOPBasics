﻿using System;
using System.Collections.Generic;
using System.Text;


    class Child
    {
    public string Name { get; set; }
    public string Birthay { get; set; }

    public Child(string name, string birthay)
    {
        this.Name = name;
        this.Birthay = birthay;
    }
}

