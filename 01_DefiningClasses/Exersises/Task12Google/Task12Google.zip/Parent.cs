﻿using System;
using System.Collections.Generic;
using System.Text;


    class Parent
    {

    public string Name { get; set; }
    public string Birthay { get; set; }

    public Parent(string name, string birthay)
    {
        this.Name = name;
        this.Birthay = birthay;
    }
}

